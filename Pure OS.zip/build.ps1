# Script to build the .apbx Playbook for AME Wizard
$ErrorActionPreference = "Stop"

$workspaceRoot = $PSScriptRoot
$srcPath = Join-Path $workspaceRoot "src"
$outputFile = Join-Path $workspaceRoot "PureOS.apbx"

# Locate 7z
$7zPaths = @(
    "7z",
    "C:\ProgramData\chocolatey\tools\7z.exe",
    "C:\Program Files\7-Zip\7z.exe",
    "C:\Program Files (x86)\7-Zip\7z.exe"
)

$7zExe = $null
foreach ($path in $7zPaths) {
    if (Get-Command $path -ErrorAction SilentlyContinue) {
        $7zExe = $path
        break
    } elseif (Test-Path $path) {
        $7zExe = $path
        break
    }
}

if (-not $7zExe) {
    Write-Error "7-Zip (7z.exe) wurde nicht gefunden! Bitte installieren Sie 7-Zip oder Chocolatey."
    exit 1
}

Write-Host "Erstelle PureOS.apbx mit $7zExe..." -ForegroundColor Cyan

# Remove existing apbx if present
if (Test-Path $outputFile) {
    Remove-Item $outputFile -Force
}

# Compress contents of src directory into .apbx
Push-Location $srcPath
try {
    & $7zExe a -pmalte -mhe=on -mx=9 $outputFile *
} finally {
    Pop-Location
}

if (Test-Path $outputFile) {
    $size = (Get-Item $outputFile).Length / 1MB
    $hash = (Get-FileHash -Algorithm SHA256 -Path $outputFile).Hash
    Write-Host ""
    Write-Host "[OK] PureOS.apbx erfolgreich erstellt! ($([math]::Round($size, 2)) MB)" -ForegroundColor Green
    Write-Host "SHA256: $hash" -ForegroundColor Yellow
} else {
    Write-Error "Fehler beim Erstellen der .apbx Datei."
}
