@echo off
:: Pure OS - Import and Apply Pure OS Power Plan
setlocal EnableDelayedExpansion

echo ============================================
echo   Pure OS Power Plan Setup
echo ============================================

set "SCHEME_GUID=11111111-1111-1111-1111-111111111111"
set "POW_FILE=%~dp0PurePowerPlan.pow"

:: Remove existing scheme with same GUID if present
powercfg -delete %SCHEME_GUID% >nul 2>&1

:: Import the Pure OS Power Plan
if exist "%POW_FILE%" (
    echo Importing Pure OS Power Plan from file...
    powercfg -import "%POW_FILE%" %SCHEME_GUID%
    if errorlevel 1 (
        echo Fallback: importing without specified GUID...
        for /f "tokens=6" %%a in ('powercfg -import "%POW_FILE%"') do (
            set "SCHEME_GUID=%%a"
        )
    )
) else (
    echo Warning: PurePowerPlan.pow not found in %~dp0, creating from default template...
    powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 %SCHEME_GUID% >nul 2>&1
    if errorlevel 1 (
        powercfg -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c %SCHEME_GUID% >nul 2>&1
    )
)

:: Set friendly name and description
echo Configuring plan name...
powercfg -changename %SCHEME_GUID% "Pure OS Performance" "Optimized power plan for Pure OS - maximum performance" >nul 2>&1

:: Activate the power plan
echo Activating Pure OS Power Plan (%SCHEME_GUID%)...
powercfg -setactive %SCHEME_GUID%

echo Pure OS Power Plan configured and activated successfully.
endlocal
